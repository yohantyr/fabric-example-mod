CHAOS CLIENT - drop-in source for the fabric-example-mod fork (MC 26.2)

1. Delete the template's com/example sources, its *.mixins.json files and ExampleMod entrypoints.
2. Copy `src/` from this zip into your repo root (merge; replace fabric.mod.json).
3. If your template has NO src/client folder, move src/client/java and src/client/resources into src/main.
4. In gradle.properties set archives_base_name=chaos-client and maven_group=dev.chaos.
5. ./gradlew build   -> jar in build/libs/
Controls: Right Shift = GUI. VeinMiner = hold sneak while mining (singleplayer / LAN host).
If the build or launch errors, paste the log to Claude.
