package dev.chaos;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

/**
 * Hold sneak while mining to break the connected vein of the same block.
 * Runs on the (integrated) server, so it works in singleplayer / LAN you host.
 */
public final class VeinMiner {
    private static final int MAX_BLOCKS = 64;
    private static boolean busy;

    public static void register() {
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (busy || !ModuleManager.VEINMINER.isEnabled()) return;
            if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) return;
            if (!sp.isShiftKeyDown() || !sp.hasCorrectToolForDrops(state)) return;

            Block target = state.getBlock();
            Set<BlockPos> seen = new HashSet<>();
            ArrayDeque<BlockPos> queue = new ArrayDeque<>();
            seen.add(pos);
            queue.add(pos);
            int mined = 0;
            busy = true;
            try {
                while (!queue.isEmpty() && mined < MAX_BLOCKS) {
                    BlockPos p = queue.poll();
                    for (int dx = -1; dx <= 1; dx++)
                        for (int dy = -1; dy <= 1; dy++)
                            for (int dz = -1; dz <= 1; dz++) {
                                BlockPos n = p.offset(dx, dy, dz);
                                if (mined >= MAX_BLOCKS || !seen.add(n)) continue;
                                if (!sl.getBlockState(n).is(target)) continue;
                                ItemStack tool = sp.getMainHandItem();
                                if (tool.isDamageableItem() && tool.getDamageValue() >= tool.getMaxDamage() - 1) return;
                                if (sp.gameMode.destroyBlock(n)) {
                                    mined++;
                                    queue.add(n);
                                }
                            }
                }
            } finally {
                busy = false;
            }
        });
    }

    private VeinMiner() {}
}
