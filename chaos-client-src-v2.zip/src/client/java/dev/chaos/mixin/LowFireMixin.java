package dev.chaos.mixin;

import dev.chaos.ModuleManager;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public class LowFireMixin {
    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void chaos$lowFire(CallbackInfo ci) {
        if (ModuleManager.LOW_FIRE.isEnabled()) ci.cancel();
    }
}
