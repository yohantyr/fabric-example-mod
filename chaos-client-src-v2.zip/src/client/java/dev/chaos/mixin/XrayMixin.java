package dev.chaos.mixin;

import dev.chaos.ModuleManager;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public class XrayMixin {
    // Signature is the one most likely to need a tweak on 26.2 - see crash log if it fails.
    @Inject(method = "shouldRenderFace", at = @At("HEAD"), cancellable = true)
    private static void chaos$xray(BlockState state, BlockState neighbor, Direction dir,
                                   CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.XRAY.isEnabled()) cir.setReturnValue(ModuleManager.isXrayTarget(state));
    }
}
