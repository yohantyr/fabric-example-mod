package dev.chaos.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.chaos.ModuleManager;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ItemInHandRenderer.class)
public class LowShieldMixin {
    // ordinal 3 = the 4th float arg (equipped progress). 0 = raised, 1 = fully lowered.
    @ModifyVariable(method = "submitArmWithItem", at = @At("HEAD"), argsOnly = true, ordinal = 3)
    private float chaos$lowShield(float progress, @Local(argsOnly = true) ItemStack stack) {
        if (ModuleManager.LOW_SHIELD.isEnabled() && stack.is(Items.SHIELD)) return Math.max(progress, 0.4f);
        return progress;
    }
}
