package dev.chaos;

/** Chaos purple palette (ARGB). */
public final class Theme {
    public static final int ACCENT = 0xFFB066FF;
    public static final int HEADER = 0xFF7B2FF7;
    public static final int ROW_ON = 0xFF9D4EDD;
    public static final int ROW_OFF = 0xFF2A0A4A;
    public static final int ROW_HOVER = 0xFF4A1A7A;
    public static final int BG = 0x90100020;
    public static final int TEXT = 0xFFFFFFFF;
    public static final int TEXT_DIM = 0xFFD9B3FF;
    private Theme() {}
}
