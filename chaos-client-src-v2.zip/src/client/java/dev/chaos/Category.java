package dev.chaos;

public enum Category {
    RENDER("Render"), WORLD("World"), PLAYER("Player"), MISC("Misc");
    public final String label;
    Category(String label) { this.label = label; }
}
