package dev.chaos;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class ChaosClient implements ClientModInitializer {
    public static final String ID = "chaosclient";
    private static KeyMapping openGui;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));
        openGui = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.chaosclient.open", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, cat));

        VeinMiner.register();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) {
                if (mc.gui.screen() == null) mc.setScreenAndShow(new ClickGui());
            }
            if (mc.player == null) return;
            for (Module m : ModuleManager.ALL) if (m.isEnabled()) m.onTick(mc);
        });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(ID, "hud"), (g, tickCounter) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.gui.hud.isHidden()) return;
            g.text(mc.font, "Chaos Client", 4, 4, Theme.ACCENT);
            int y = 16;
            for (Module m : ModuleManager.ALL) {
                if (!m.isEnabled()) continue;
                g.text(mc.font, m.name, 4, y, Theme.TEXT_DIM);
                y += 10;
            }
        });
    }
}
