package dev.chaos;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private static final Map<Block, Boolean> TARGET_CACHE = new ConcurrentHashMap<>();

    public static final Module XRAY = add(new Module("Xray", Category.RENDER) {
        @Override protected void onEnable() { reloadChunks(); }
        @Override protected void onDisable() { reloadChunks(); }
    });

    public static final Module FULLBRIGHT = add(new Module("Fullbright", Category.RENDER) {
        @Override public void onTick(Minecraft mc) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        @Override protected void onDisable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION);
        }
    });

    public static final Module LOW_SHIELD = add(new Module("Low Shield", Category.RENDER));
    public static final Module LOW_FIRE = add(new Module("Low Fire", Category.RENDER));
    public static final Module VEINMINER = add(new Module("VeinMiner", Category.WORLD));

    private static Module add(Module m) { ALL.add(m); return m; }

    public static List<Module> in(Category c) {
        return ALL.stream().filter(m -> m.category == c).toList();
    }

    /** Blocks that stay visible while Xray is on (any *_ore, ancient debris, chests, spawners). */
    public static boolean isXrayTarget(BlockState s) {
        return TARGET_CACHE.computeIfAbsent(s.getBlock(), b -> {
            String p = BuiltInRegistries.BLOCK.getKey(b).getPath();
            return p.endsWith("_ore") || p.equals("ancient_debris") || p.endsWith("chest") || p.equals("spawner");
        });
    }

    /**
     * Re-mesh the world. Mojang renamed LevelRenderer.allChanged() to
     * invalidateCompiledGeometry(...) in 26.2, so we find whichever exists and fill args by type.
     */
    private static void reloadChunks() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.levelRenderer == null) return;
            Object gr = find(GameRenderer.class, mc);
            Object[] roots = { mc, mc.level, mc.options, gr };
            for (Method m : LevelRenderer.class.getDeclaredMethods()) {
                String n = m.getName();
                if (!n.equals("invalidateCompiledGeometry") && !n.equals("allChanged")) continue;
                Class<?>[] types = m.getParameterTypes();
                Object[] args = new Object[types.length];
                boolean ok = true;
                for (int i = 0; i < types.length; i++) {
                    args[i] = find(types[i], roots);
                    if (args[i] == null) ok = false;
                }
                if (!ok) continue;
                m.setAccessible(true);
                m.invoke(mc.levelRenderer, args);
                return;
            }
        } catch (Throwable t) {
            System.err.println("[ChaosClient] chunk reload failed: " + t);
        }
    }

    private static Object find(Class<?> type, Object... roots) {
        for (Object root : roots) {
            if (root == null) continue;
            if (type.isInstance(root)) return root;
            for (Method m : root.getClass().getMethods()) {
                if (m.getParameterCount() == 0 && type.isAssignableFrom(m.getReturnType())) {
                    try { Object o = m.invoke(root); if (o != null) return o; } catch (Exception ignored) {}
                }
            }
            for (Field f : root.getClass().getFields()) {
                if (type.isAssignableFrom(f.getType())) {
                    try { Object o = f.get(root); if (o != null) return o; } catch (Exception ignored) {}
                }
            }
        }
        return null;
    }

    private ModuleManager() {}
}
