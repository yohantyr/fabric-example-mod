package dev.chaos;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class ClickGui extends Screen {
    private static final int PANEL_W = 110, ROW_H = 16, TOP = 30, GAP = 10;

    public ClickGui() { super(Component.literal("Chaos Client")); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        g.fill(0, 0, width, height, Theme.BG);
        int x = 30;
        for (Category c : Category.values()) {
            var mods = ModuleManager.in(c);
            if (mods.isEmpty()) continue;
            g.fill(x, TOP, x + PANEL_W, TOP + ROW_H, Theme.HEADER);
            g.text(font, c.label, x + 6, TOP + 4, Theme.TEXT);
            int y = TOP + ROW_H;
            for (Module m : mods) {
                boolean hover = mx >= x && mx < x + PANEL_W && my >= y && my < y + ROW_H;
                int bg = m.isEnabled() ? Theme.ROW_ON : hover ? Theme.ROW_HOVER : Theme.ROW_OFF;
                g.fill(x, y, x + PANEL_W, y + ROW_H, bg);
                g.text(font, m.name, x + 6, y + 4, m.isEnabled() ? Theme.TEXT : Theme.TEXT_DIM);
                y += ROW_H;
            }
            x += PANEL_W + GAP;
        }
        g.text(font, "Chaos Client", 30, 12, Theme.ACCENT);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            int x = 30;
            for (Category c : Category.values()) {
                var mods = ModuleManager.in(c);
                if (mods.isEmpty()) continue;
                int y = TOP + ROW_H;
                for (Module m : mods) {
                    if (event.x() >= x && event.x() < x + PANEL_W && event.y() >= y && event.y() < y + ROW_H) {
                        m.toggle();
                        return true;
                    }
                    y += ROW_H;
                }
                x += PANEL_W + GAP;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }
}
