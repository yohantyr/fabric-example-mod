package dev.chaos;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();

    public static final Module XRAY = add(new Module("Xray", Category.RENDER) {
        @Override protected void onEnable() { reload(); }
        @Override protected void onDisable() { reload(); }
        private void reload() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.levelRenderer != null) mc.levelRenderer.allChanged();
        }
    });

    public static final Module FULLBRIGHT = add(new Module("Fullbright", Category.RENDER) {
        @Override public void onTick(Minecraft mc) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        @Override protected void onDisable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION);
        }
    });

    public static final Module LOW_SHIELD = add(new Module("Low Shield", Category.RENDER));
    public static final Module LOW_FIRE = add(new Module("Low Fire", Category.RENDER));
    public static final Module VEINMINER = add(new Module("VeinMiner", Category.WORLD));

    private static Module add(Module m) { ALL.add(m); return m; }

    public static List<Module> in(Category c) {
        return ALL.stream().filter(m -> m.category == c).toList();
    }

    /** Blocks that stay visible while Xray is on. */
    public static boolean isXrayTarget(BlockState s) {
        return s.is(BlockTags.COAL_ORES) || s.is(BlockTags.IRON_ORES) || s.is(BlockTags.GOLD_ORES)
            || s.is(BlockTags.DIAMOND_ORES) || s.is(BlockTags.EMERALD_ORES) || s.is(BlockTags.LAPIS_ORES)
            || s.is(BlockTags.REDSTONE_ORES) || s.is(BlockTags.COPPER_ORES)
            || s.is(Blocks.ANCIENT_DEBRIS) || s.is(Blocks.NETHER_QUARTZ_ORE) || s.is(Blocks.NETHER_GOLD_ORE)
            || s.is(Blocks.CHEST) || s.is(Blocks.SPAWNER);
    }

    private ModuleManager() {}
}
